package com.vinay.student;

import java.util.Collections;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class StudentTest1Application {

	public static void main(String[] args) {
		SpringApplication.run(StudentTest1Application.class, args);
	}
	
	@Bean
	public Docket SwaggerConfiguration() {
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.paths(PathSelectors.ant("/studentapi/*"))
				.apis(RequestHandlerSelectors.basePackage("com.vinay"))
				.build()
				.apiInfo(apiDetails());
	}
	
	private ApiInfo apiDetails() {
		return new ApiInfo(
				"Student Management Application",
				"Sample Api for Spring boot",
				"1.0",
				"Free to use",
				new springfox.documentation.service.Contact("Vinay Murahari", "http://localhost:8082/vinay/", "muraharivinay@gmail.com"),
				"API Licence",
				"http://localhost:8082/apiLicence/",
				Collections.emptyList());
				
	}

}
