insert into CAL.student(studentId,studentAdress,studentFname,studentLname)
values(101,"Burwood","vinay","murahari"),
(102,"Burwood","vaishali","thakoor"),
(103,"Boxhill","Raju","Murahari");