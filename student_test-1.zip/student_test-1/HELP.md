# Getting Started
1. Setup your Schema in your MySql workbench as demo.
2. give your Mysql user name and password in application properties.
3. run the program as spring application "StudentTest1Application.
4. 